# *** warning supresion
import warnings
warnings.filterwarnings("ignore")
# *** numeric libraries
import numpy as np
# *** graph libraries
import matplotlib.pyplot as plt

class FAPV21(object):
	def __init__(self, X=None, D=None, L=None, La=None, f=None, A=None, a=1,
				Y=None, y=None, S=None,	N=None, Nc=None, Na=None, Ni=None, Nt=None ):

		self.D = D
		self.X = X
		
		self.Y = Y
		self.y = y
		
		self.S = S

		self.L = L
		self.La = La

		self.a = a
		self.A = A

		self.f = f

		self.N = N
		self.Nc = Nc

		self.Na = Na
		self.Ni = Ni
		self.Nt = Nt

		self.colors = [ '#d0a64b', '#39beb9', '#1579c5', '#7b3786', '#F90061',
						'#d0a64b', '#39beb9', '#1579c5', '#7b3786', '#F90061',
						'#d0a64b', '#39beb9', '#1579c5', '#7b3786', '#F90061',] 

	def aling(self, D=None, S=None, Nc=None, Na=None, Ni=None, a=None,
					area='gaussian_coeficient', non_negativity=True, linear_adjust=True,
					mu_range=None, sigma_range=None, save=True
					): 
		# variable setter for aling_FAPVXX  
		try: 
			if not D  == None: 	self.D  = D
		except:	pass

		try: 
			if not S  == None: self.S  = S
		except:	pass

		try: 
			if save: self.mu_range = mu_range
		except: pass

		try: 
			if save: self.sigma_range = sigma_range
		except: pass

		if not Nc == None: self.Nc = Nc
		if not Na == None: self.Na = Na
		if not Ni == None: self.Ni = Ni
		if not a  == None: self.a  = a
		

		if self.a == 1: 
			# 3 order, 2 way, 1 aligned channel, 1non aligned channel  
			self.aling_FAPV21(	D=self.D, S=self.S, Nc=self.Nc, Na=self.Na, Ni=self.Ni, 
								area=area, non_negativity=non_negativity, linear_adjust=linear_adjust,
								mu_range=mu_range, sigma_range=sigma_range, save=save)

		return self.Da, self.La, self.L # 
		
	def aling_FAPV21(self, D=None, S=None, Nc=None, Na=None, Ni=None, v=1, 
					area='gaussian_coeficient', non_negativity=True, linear_adjust=True,
					mu_range=None, sigma_range=None, save=True
					): 		# FPAV for 3 order, 2 way, 1 aligned channel, 1non aligned channel 
		# ----- Alignment algorithm for 3rd order data with 2 aligned channels ----- #
		# 
		# D 		:	N-MAT 		:		N-array/Matrix non-aligned data D => [N,l1,l2]
		# S 		:	N-MAT 		:		N-array/Matrix well aligned channels  S => [[self.f,l1],[self.f,l2]] 
		# Nc		:	INT 		: 		number of calibration samples.
		# Na		:	INT 		: 		number of analites.
		# Ni		:	INT 		: 		number of interferentes.
		# v 		: 	BOOL		: 		verboisity
		# area 		:   str 		: 		area preserving mode {'gaussian', 'max', 'sum'}
		# non_negativity :	BOOL  	: 		NON-negativity constrain
		# mu_range	:	N-array 	: 		this parameter consists of the exploration range of mu (of the functions of the functional space)
		#									eg: mu_range=np.arange(150, 300, 3)
		# sigma_range : N-array		; 		this parameter consists of the exploration range of sigma (of the functions of the functional space)
		#									eg: sigma_range=np.arange(3, 30, 1)
		# save 		: 	BOOL		:		this save the
		# ------------------------------------------------------------------------------- #
		# self.D 		:	N-MAT 		:		N-array/Matrix non-aligned data D => [N,l1,l2]
		# self.S 		:	N-MAT 		:		N-array/Matrix well aligned channels  S => [[self.f,l1],[self.f,l2]] 
		# self.Nc		:	INT 		: 		number of calibration samples.
		# self.Na		:	INT 		: 		number of analites.
		# self.Ni		:	INT 		: 		number of interferentes.
		# ------------------------------------------------------------------------------- #
		# self.S  	: [L1, L2] | L1=[f,l1], L2=[f,l2] 
		# self.f  	: numero de factores = Numero de analitos(Na) + Numero de interferentes(Ni)
		# self.N  	: Numero de muestras de calibrado(Nc) + Numero de muestras test(Nt)
		# l1 		: number of variables of channel 1
		# l2 		: number of variables of channel 2
		# l3 		: number of variables of channel 3

		# --- Define variables --- # 
		if v >= 1: print( ('0- Setting variables') )
		try: 
			if not D  == None: self.D  = D
		except:	pass

		try: 
			if not S  == None: self.S  = S
		except:	pass
		if not Nc == None: self.Nc = Nc
		if not Na == None: self.Na = Na
		if not Ni == None: self.Ni = Ni

		self.D = self.X

		self.N, l1, l2  =  self.D.shape
		self.Nt, self.f = self.N - self.Nc, self.Na + self.Ni

		# --- STEPS --- #
		# (0) estimation of well aligned channels (commonly spectral channels)
		# (1) Estimate non-spectral channels
		# (2) Align non-spectral channels
		# (3) Rebuild the samples
		# (4) Postprocessing

			# ------ ------ MUESTRAS DE CALIBRADO ------ ------ #
		# --- Z --- #
		if v >= 1: print( ('1- Inicializing matrix') )
		Ze = self.S[0][:self.Na, :]
		Z = Ze

	  	# --- Y --- #
		Ye = self.D[0,:,:]
		for n in range(1, self.Nc): Ye = np.concatenate( (Ye ,  self.D[n,:,:]), axis=1)
		Y = Ye

	  	# --- X(Lc) --- #
		if v >= 1: print( ('2- Estimation of non-aligned channel') )
		Lc=np.dot(Y.T, np.linalg.pinv(Z) )

		if non_negativity: 	Lc = np.where(Lc>0, Lc, 0) 			

		self.L = np.zeros( (self.Nc, self.Na, l2) )
		for nc in range(self.Nc): self.L[nc,:,:] = Lc[nc*l2:(nc+1)*l2,:].T

		# ------ AREAS ------ #
		if area == 'sum':
			self.A = np.sum( self.L, axis=2 ) # [N, self.f]

		if area == 'max':
			self.A = np.max( self.L, axis=2 )  

		if area=='gaussian_coeficient':
			#  evaluate proyection coef and gaussian parameters 
			coef = np.zeros((self.Nc+self.Nt, self.Na+self.Ni))
			Gcoef = np.zeros((self.Nc+self.Nt, self.Na+self.Ni, 2))
			for nc in range(self.Nc):
				for na in range(self.Na):
					CC = self.G( self.L[nc,na,:], mu_range=mu_range, sigma_range=sigma_range)
					coef[nc, na] = CC[1]
					Gcoef[nc, na, :] = CC[2], CC[3] 
					if v >= 1: print('Gcoef: {:e} mead:{} sd:{} :: sample: {} factor: {} '.format(CC[1], CC[2], CC[3], nc, na))
			self.A = coef

		if area=='gaussian_coeficient':
			#  evaluate all eigen functions (this step is not necesary ) 
			self.all_gauss_aling = np.zeros((self.Nc+self.Nt, self.Na+self.Ni, l2))
			for na in range(self.Na):
				for nc in range(self.Nc): 
					self.all_gauss_aling[nc, na, :] = self.gaussian(np.mean(Gcoef[:, na, 0]), np.mean(Gcoef[:, na, 1]), l2) *self.A[nc, na] 

			self.all_gauss = np.zeros((self.Nc+self.Nt, self.Na+self.Ni, l2))
			for na in range(self.Na):
				for nc in range(self.Nc): 
					self.all_gauss[nc, na, :] = self.gaussian(Gcoef[nc, na, 0], Gcoef[nc, na, 1], l2) *self.A[nc, na] 

			# ------ FUNCTIONAL ALIGNMENT ------ # Estimacion del tensor de datos alineado (self.Da)
		if v >= 1: print( ('3- Functional alignement (calibration samples)') )
		Lmax, Amax, self.Da, sigma = np.zeros((self.Na)), np.argmax(self.A, axis=0), np.zeros((self.N, l1, l2)), l2/self.f/30
		for na in range(self.Na): Lmax[na] = np.argmax(self.L, axis=2)[Amax[na]][na]

		if v >= 1: print( ('4- Recostructing data (calibration samples)') )
		for na in range(self.Na):
			Ma = np.tensordot(self.S[0][na, :], self.gaussian(Lmax[na], sigma, l2) , axes=0)
			for nc in range(self.Nc): self.Da[nc,:,:] += Ma*self.A[nc, na]

		# --- Estimacion de los canales originalemente NO alineados(self.L) ya alineados(self.La).
		self.La = np.zeros( (self.N, self.f, l2) )
		for na in range(self.Na):
			for nc in range(self.Nc): self.La[nc, na, :] = self.gaussian(Lmax[na], sigma, l2)*self.A[nc, na]

	  	#  ------ ------ TEST SAMPLES ------ ------ #
		if self.Nt > 0:
			if v >= 1: print( ('3b- Functional alignement (test samples)') )
			# --- Z --- #
			Ze = self.S[0]
			Z = Ze

			# --- Y --- #
			Ye = self.D[self.Nc,:,:]
			for n in range(1,self.Nt): Ye = np.concatenate( (Ye ,  self.D[self.Nc+n,:,:]), axis=1)
			Y = Ye

			# --- X(Lc) --- #
			Lc= np.dot(Y.T, np.linalg.pinv(Z) )
			if non_negativity: 	Lc = np.where(Lc>0, Lc, 0) 

			self.L = np.zeros( (self.Nt, self.f, l2) )
			for nt in range(self.Nt): self.L[nt,:,:] = Lc[nt*l2:(nt+1)*l2,:].T 
		
			# ------ AREAS ------ #
			if area == 'sum':
				self.A = np.sum( self.L, axis=2 ) 

			if area == 'max':
				self.A = np.max( self.L, axis=2 )  

			if area=='gaussian_coeficient':
				#  evaluate proyection coef and gaussian parameters
				coef = np.zeros((self.Nt, self.f))
				Gcoef = np.zeros((self.Nt, self.f, 2))
				for nc in range(self.Nt):
					for na in range(self.f):
						CC = self.G( self.L[nc,na,:], mu_range=mu_range, sigma_range=sigma_range )
						coef[nc, na] = CC[1]
						Gcoef[nc, na, :] = CC[2], CC[3] 
						if v >= 1: print('Gcoef: {:e} mead:{} sd:{} :: sample: {} factor: {} '.format(CC[1], CC[2], CC[3], nc, na))
				self.A = coef

			if linear_adjust:
				pass # not implemented

			if area=='gaussian_coeficient':
				#  evaluate all eigen functions (this step is not necesary ) 
				for na in range(self.Na+self.Ni):
					for nt in range(self.Nt): 
						self.all_gauss_aling[self.Nc+nt, na, :] = self.gaussian(np.mean(Gcoef[:, na, 0]), np.mean(Gcoef[:, na, 1]), l2) *self.A[nt, na] 

				for na in range(self.Na+self.Ni):
					for nt in range(self.Nt): 
						self.all_gauss[self.Nc+nt, na, :] = self.gaussian(Gcoef[nt, na, 0], Gcoef[nt, na, 1], l2) *self.A[nt, na] # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

			# --- FUNCTIONAL ALIGNMENT --- # Estimation of aligned data tensor (self.Da)
			if v >= 1: print( ('4b- Recostructing data (test samples)') )
			for na in range(self.Na):
				Ma = np.tensordot( self.S[0][na, :], self.gaussian(Lmax[na], sigma, l2) , axes=0)
				for nt in range(self.Nt): self.Da[self.Nc+nt,:,:] += Ma*self.A[nt, na]

		# --- Estimation of channels originally NOT aligned (self.L) but already aligned (self.La).
		for na in range(self.Na):
			for nt in range(self.Nt): 
				self.La[nt+self.Nc, na, :] = self.gaussian(Lmax[na], sigma, l2)*self.A[nt, na]
				self.La[nt+self.Nc, na, :] = self.gaussian(Gcoef[nt, na, 0], sigma, l2)*self.A[nt, na]

		print('Successful alignment.')

		return self.Da, self.La, self.L 
		# return self.Da, self.La, self.L
		# ---------------------------------------------------- #
		# self.Da 		:	ndarray  :  well aligned data 
		# self.La 		:	ndarray  :  well aligned loadings   shape [Nt+Nc, Na, l2]
		# self.L 		:	ndarray  :  stimated loadings		shape [Nt+Nc, Na, l2]
		# ---------------------------------------------------- #
		#	Nt 			: 	 INT 	:	number of test samples 
		#	Nc 			: 	 INT 	:	number of calibration samples 
		#	Na 			: 	 INT 	:	number analites (calibrated factors) 
		#	Ni 			: 	 INT 	:	number non interfers (non-calibrated factors) 
		#	l2 			: 	 INT 	:	number variables of the non-aligned way
		# ---------------------------------------------------- #
		
	def gaussian(self, mu, sigma, n, ):
			return np.e**(-1.0/2 * ((mu-np.arange(n))/sigma)**2) / (np.linalg.norm(np.e**(-1.0/2 * ((mu-np.arange(n))/sigma)**2)))

	def Lorentz(self,n,a,m):
		return (a*1.0/(np.pi*((np.arange(0, n, dtype=np.float32)-m))**2+a**2))

	def plot(self, names):
		color = ['tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', ]

		fig_all, ax_all = [], []

		for n in range(self.Na):
			fig, ax = plt.subplots()
			fig_all.append(fig)
			ax_all.append(ax)

		for n in range(self.Na):
			fig, ax = fig_all[n], ax_all[n]
			
			dat = self.all_gauss[:,n,:]
			color = [ 0.7 + 0.3*np.max(dat[n,:])/np.max(dat) for n in range(dat.shape[0])]
			ax.plot( np.linspace(0,6.5,391), dat[0,:], color=(color[0], 0.5, 0.3 ), lw=1.5, alpha=0.6, label=names[n] )
			for n in range(1, dat.shape[0]):
				ax.plot( np.linspace(0,6.5,391), dat[n,:], color=(color[n], 0.5, 0.3 ), lw=1.5, alpha=0.6 )

			ax.set_xlabel('Elution time (min)', fontsize=12)
			ax.set_ylabel('Absorbance (a.u.)', fontsize=12)

			ax.spines["right"].set_linewidth(2)
			ax.spines["right"].set_color("#333333")
			ax.spines["left"].set_linewidth(2)
			ax.spines["left"].set_color("#333333")
			ax.spines["top"].set_linewidth(2)
			ax.spines["top"].set_color("#333333")
			ax.spines["bottom"].set_linewidth(2)
			ax.spines["bottom"].set_color("#333333")

			legend = ax.legend(loc='upper right', shadow=True, fontsize='large')
			legend.get_frame().set_facecolor('#FFFFFF')

	def plot_spectra(self, names=None, colors=None):
		try:
			if   colors == None:			color = self.colors
			elif colors == 'vainilla':		color = ['tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', ]
			else:							color = colors
		except:		print('ERROR :: code 002c FAPV21.plot_spectra() :: Can not set colors')

		try:		fig, ax = plt.subplots()
		except:		print('ERROR :: code 002c FAPV21.plot_spectra() :: Can not make axes')

		try:
			for n in range(self.Na):
				if names != None:	ax.plot( self.S[0][n,:].T, '-o', color=color[n], lw=1.5, alpha=0.6, ms=3, label=names[n])
				else:				ax.plot( self.S[0][n,:].T, '-o', color=color[n], lw=1.5, alpha=0.6, ms=3 )
		except:		print('ERROR :: code 002c FAPV21.plot_spectra() :: Can not PLOT spectra')

		try:
			ax.set_xlabel('variable', fontsize=12);		ax.set_ylabel('Absorbance (a.u.)', fontsize=12)
			ax.spines["right"].set_linewidth(2); 		ax.spines["right"].set_color("#333333")
			ax.spines["left"].set_linewidth(2); 		ax.spines["left"].set_color("#333333")
			ax.spines["top"].set_linewidth(2); 			ax.spines["top"].set_color("#333333")
			ax.spines["bottom"].set_linewidth(2); 		ax.spines["bottom"].set_color("#333333")
		except:		print('ERROR :: code 002c FAPV21.plot_spectra() :: Can not configure axis')


		try:
			if names != None:
				legend = ax.legend(loc='upper right', shadow=True, fontsize='large')
				legend.get_frame().set_facecolor('#FFFFFF')
		except:		print('ERROR :: code 002c FAPV21.plot_spectra() :: Can not configure legend')

	def summary(self,):
		print(' *** Sensors ***')
		for i, n in enumerate(self.D.shape):		
			if i == 0: print('  *  Loaded data has '+str(n)+' samples')
			elif i != 3: print('  *  (aligned) Channel '+str(i)+' has '+str(n)+' sensors')
			elif i == 3: print('  *  (NON-aligned) Channel '+str(i)+' has '+str(n)+' sensors')

	def load_fromDATA(self, data=None):
		try: self.__dict__ = data.__dict__.copy() 
		except: pass

	def G(self, data=None, mu_range=np.arange(160, 280, 3), sigma_range=np.arange(3, 30, 2) ):
		if not type(data) is np.ndarray:		 	data =self.X

		if type(mu_range) is list:					mu_range = np.array(mu_range)
		elif not type(mu_range) is np.ndarray: 		mu_range = range(0, data.shape[0])

		if type(sigma_range) is list:				sigma_range = np.array(sigma_range)
		elif not type(sigma_range) is np.ndarray: 	sigma_range = range(1, data.shape[0])
		
		n = data.shape[0]

		base = np.array([ self.gaussian(mu, sigma, n) for mu in mu_range for sigma in sigma_range ])
		base_parameters_list = np.array([ [mu, sigma] for mu in mu_range for sigma in sigma_range ]) 

		proy = base.dot(data)
		max_arg   = np.argmax(proy)
		max_value = np.max(proy)
		return max_arg, max_value, base_parameters_list[max_arg][0], base_parameters_list[max_arg][1]

	def G_vector_descompose(self, data, G_max, v=False):
		L1 = data.shape[0]
		coef = np.zeros((G_max, 4))
		resto = data
		for g in range(G_max):
			if v: print('Compleate {}%'.format(100*g/G_max) )
			coef[g, :] = G( resto )
			resto = resto - gaussian(coef[g, 2], coef[g, 3], L1)*coef[g, 1]
		return coef

	def G_matrix_descompose(self, data, G_max, v=False):
		L1, L2 = data.shape

		coef = np.zeros(( L1, G_max, 4))
		for l1 in range(L1):
			if v: print('Compleate {}%'.format(100*l1/L1) )
			coef[l1, :, :] = G_vector_descompose( data=data[l1, :], G_max=G_max )

		return coef

	def G_tensor_descompose(self, data, G_max, v=True):
		N, L1, L2 = data.shape

		coef = np.zeros((N, 2, G_max, 4))
		for n in range(N):
			if v: print('Compleate {}%'.format(100*n/N) )
			coef[n, :, :, :] = G_matrix_descompose( data=data[n, :, :], G_max=G_max )

		return coef

'''
eg.
fapv21 = FAPV21()
fapv21.S = [spectra information]
Da, La, L = fapv21.aling( area='gaussian_coeficient') # area, mu_range and sigma_range should be chosen carefully
'''

